---
description: Ensure class names match filenames for easy imports. Use AutoBackend to automatically rename and refactor model files.
keywords: AutoBackend, ultralytics, nn, autobackend, check class names, neural network
---

## AutoBackend
---
### ::: ultralytics.nn.autobackend.AutoBackend
<br><br>

## check_class_names
---
### ::: ultralytics.nn.autobackend.check_class_names
<br><br>
