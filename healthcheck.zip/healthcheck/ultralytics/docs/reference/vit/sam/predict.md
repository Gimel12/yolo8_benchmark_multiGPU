---
description: The VIT SAM Predictor from Ultralytics provides object detection capabilities for YOLO. Learn how to use it and speed up your object detection models.
keywords: Ultralytics, VIT SAM Predictor, object detection, YOLO
---

## Predictor
---
### ::: ultralytics.vit.sam.predict.Predictor
<br><br>