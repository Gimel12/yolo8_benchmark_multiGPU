---
description: Discover the YOLO model of Ultralytics engine to simplify your object detection tasks with state-of-the-art models.
keywords: YOLO, object detection, model, architecture, usage, customization, Ultralytics Docs
---

## YOLO
---
### ::: ultralytics.yolo.engine.model.YOLO
<br><br>
