---
description: Ensure YOLOv5 models meet constraints and standards with the BaseValidator class. Learn how to use it here.
keywords: Ultralytics, YOLO, BaseValidator, models, validation, object detection
---

## BaseValidator
---
### ::: ultralytics.yolo.engine.validator.BaseValidator
<br><br>
