---
description: '"Improve YOLO model performance with on_fit_epoch_end callback. Learn to integrate with Ray Tune for hyperparameter tuning. Ultralytics YOLO docs."'
keywords: on_fit_epoch_end, Ultralytics YOLO, callback function, training, model tuning
---

## on_fit_epoch_end
---
### ::: ultralytics.yolo.utils.callbacks.raytune.on_fit_epoch_end
<br><br>
