import argparse
from ultralytics import YOLO

def train_model(batch, device, epochs):
    # Load a model
    model = YOLO("yolov8l.yaml")  # build a new model from scratch
    model = YOLO("yolov8l.pt")    # load a pretrained model (recommended for training)

    # Train the model
    results = model.train(data="VisDrone.yaml", epochs=epochs, imgsz=1152,
                          batch=batch, device=device, name='yolov8l_test', cache=False, close_mosaic=8,
                          project="yolov8l_20230618", flipud=0.4, fliplr=0.4,
                          degrees=10.487, translate=0.12953, scale=0.25, shear=0.18715, mixup=0.0, mosaic=1.0,
                          patience=0, resume=False, overlap_mask=True)

def main():
    parser = argparse.ArgumentParser(description='Training parameters for YOLO')
    
    parser.add_argument('--batch', type=int, default=8, help='Batch size for training')
    parser.add_argument('--device', nargs='+', type=int, default=[0], help='Device(s) for training e.g. 0 or 0 1 for multiple GPUs')
    parser.add_argument('--epochs', type=int, default=80, help='Number of epochs')
    
    args = parser.parse_args()
    
    train_model(args.batch, args.device, args.epochs)

if __name__ == "__main__":
    main()

